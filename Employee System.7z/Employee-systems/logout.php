<?php

session_start();

// مسح كل بيانات الجلسة
session_unset();  // مسح كل المتغيرات المخزنة في الجلسة
session_destroy(); // تدمير الجلسة

// إعادة التوجيه إلى صفحة تسجيل الدخول بعد الخروج
header("Location: http://localhost/Employee-systems/login.php");
// redirect('login.php');
exit();
?>
