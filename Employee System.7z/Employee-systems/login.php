<?php
// Database Connection
include_once './App/configDatabase.php';
include_once './App/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$username_error = "";
$password_error = "";

if (isset($_SESSION['user'])) {
    redirect('index.php');
    exit();
}

if (isset($_POST['submit'])) {
    // استلام البيانات بدون أي تأمين أو فلترة
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $username_error = "الرجاء إدخال اسم المستخدم وكلمة المرور!";
    } else {
        // ❌ استعلام فيه ثغرة SQL Injection واضحة
        $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);

            // تسجيل الدخول
            $_SESSION['user'] = [
                'id' => $user_data['id'],
                'fullname' => $user_data['fullname'],
                'username' => $user_data['username'],
                'role' => $user_data['role']
            ];
            redirect('index.php');
            exit();
        } else {
            $password_error = "اسم المستخدم أو كلمة المرور غير صحيحة!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - غير آمن</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #fff;
        }

        .login-title {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

        .login-btn {
            width: 100%;
            padding: 10px;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <h1 class="login-title">تسجيل الدخول</h1>
        <form method="POST">
            <div class="input-group">
                <input type="text" name="username" class="form-control" placeholder="اسم المستخدم" required>
            </div>
            <?php if ($username_error): ?>
                <div class="error-message"><?= $username_error; ?></div>
            <?php endif; ?>
            <div class="input-group">
                <input type="password" name="password" class="form-control" placeholder="كلمة المرور" required>
            </div>
            <?php if ($password_error): ?>
                <div class="error-message"><?= $password_error; ?></div>
            <?php endif; ?>
            <button class="btn btn-danger login-btn" type="submit" name="submit">دخول</button>
        </form>
    </div>
</div>
</body>
</html>
