<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';

$message = null;
$errors = [];

// الحصول على معرف الموظف من URL
if (!isset($_GET['edit']) || !is_numeric($_GET['edit'])) {
    header("Location: index.php");
    exit;
}

$employee_id = $_GET['edit'];

// جلب بيانات الموظف من قاعدة البيانات
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: index.php");
    exit;
}

$employee = $result->fetch_assoc();

// معالجة النموذج عند الإرسال
if (isset($_POST['send'])) {
    // Sanitize Inputs
    $name            = filterInputs($_POST['name']);
    $employee_number = filterInputs($_POST['employee_number']);
    $position        = filterInputs($_POST['position']);
    $department      = filterInputs($_POST['department']);
    $email           = filterInputs($_POST['email']);
    $phone           = filterInputs($_POST['phone']);
    $salary          = filterInputs($_POST['salary']);
    $hire_date       = filterInputs($_POST['hire_date']);
    $status          = filterInputs($_POST['status']);
    $user_id         = filterInputs($_POST['user_id']); // إضافة user_id

    // Validation
    if (empty($name)) {
        $errors['name'] = "Name is required.";
    }

    if (empty($employee_number)) {
        $errors['employee_number'] = "Employee Number is required.";
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format.";
    }

    if (!empty($salary) && !is_numeric($salary)) {
        $errors['salary'] = "Salary must be a number.";
    }

    // Check unique employee_number
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM employees WHERE employee_number = ? AND id != ?");
        $stmt->bind_param("si", $employee_number, $employee_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors['employee_number'] = "Employee number already exists.";
        }
        $stmt->close();
    }

    // Check if user_id is valid
    if (empty($user_id)) {
        $errors['user_id'] = "User selection is required.";
    }

    // Update employee if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE employees SET name = ?, employee_number = ?, position = ?, department = ?, email = ?, phone = ?, salary = ?, hire_date = ?, status = ?, user_id = ? WHERE id = ?");
        $stmt->bind_param("ssssssdsiii", $name, $employee_number, $position, $department, $email, $phone, $salary, $hire_date, $status, $user_id, $employee_id);

        if ($stmt->execute()) {
            $message = "Employee updated successfully.";
        } else {
            $errors['general'] = "Error while updating employee.";
        }

        $stmt->close();
    }

    mysqli_close($conn);
}
?>

<main id="main" class="main">
    <div class="container">
        <div class="card shadow-lg my-4">
            <?php if ($message): ?>
                <div class="alert alert-success text-center mb-4" id="successMessage">
                    <h3><?= $message ?></h3>
                </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-danger text-center mb-4">
                    <?= $errors['general'] ?>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <h5 class="card-title mb-4 d-flex justify-content-between align-items-center">
                    Edit Employee
                    <a class="btn btn-dark btn-sm" href="<?= URL('App/view/Employees/index.php') ?>">View All Employees</a>
                </h5>

                <form method="post" class="row g-4 needs-validation" novalidate>
                    <!-- Name -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter full name" value="<?= $employee['name'] ?>" required>
                        <?= isset($errors['name']) ? "<div class='invalid-feedback d-block'>{$errors['name']}</div>" : '' ?>
                    </div>

                    <!-- Employee Number -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Employee Number</label>
                        <input type="text" name="employee_number" class="form-control" placeholder="Enter employee ID" value="<?= $employee['employee_number'] ?>" required>
                        <?= isset($errors['employee_number']) ? "<div class='invalid-feedback d-block'>{$errors['employee_number']}</div>" : '' ?>
                    </div>

                    <!-- Position -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Position</label>
                        <input type="text" name="position" class="form-control" placeholder="Job title" value="<?= $employee['position'] ?>">
                    </div>

                    <!-- Department -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Department</label>
                        <input type="text" name="department" class="form-control" placeholder="Department name" value="<?= $employee['department'] ?>">
                    </div>

                    <!-- Email -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="example@mail.com" value="<?= $employee['email'] ?>">
                        <?= isset($errors['email']) ? "<div class='invalid-feedback d-block'>{$errors['email']}</div>" : '' ?>
                    </div>

                    <!-- Phone -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" placeholder="Enter phone number" value="<?= $employee['phone'] ?>">
                    </div>

                    <!-- Salary -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Salary</label>
                        <input type="number" name="salary" step="0.01" class="form-control" placeholder="Salary in EGP" value="<?= $employee['salary'] ?>">
                        <?= isset($errors['salary']) ? "<div class='invalid-feedback d-block'>{$errors['salary']}</div>" : '' ?>
                    </div>

                    <!-- Hire Date -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Hire Date</label>
                        <input type="date" name="hire_date" class="form-control" value="<?= $employee['hire_date'] ?>">
                    </div>

                    <!-- Status -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="نشط" <?= $employee['status'] == 'نشط' ? 'selected' : '' ?>>نشط</option>
                            <option value="غير نشط" <?= $employee['status'] == 'غير نشط' ? 'selected' : '' ?>>غير نشط</option>
                        </select>
                    </div>

                    <!-- User -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">User</label>
                        <select name="user_id" class="form-select" required>
                            <option value="">Select User</option>
                            <?php
                            // جلب جميع المستخدمين من قاعدة البيانات
                            $stmt = $conn->prepare("SELECT id, username FROM users");
                            $stmt->execute();
                            $result = $stmt->get_result();
                            while ($user = $result->fetch_assoc()) {
                                // تحديد المستخدم المعين إذا كان هناك
                                $selected = ($employee['user_id'] == $user['id']) ? 'selected' : '';
                                echo "<option value=\"{$user['id']}\" {$selected}>{$user['username']}</option>";
                            }
                            ?>
                        </select>
                        <?= isset($errors['user_id']) ? "<div class='invalid-feedback d-block'>{$errors['user_id']}</div>" : '' ?>
                    </div>

                    <!-- Buttons -->
                    <div class="col-12 text-center mt-3">
                        <button type="submit" name="send" class="btn btn-primary px-4">Submit</button>
                        <button type="reset" class="btn btn-outline-secondary px-4">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.display = 'none';
            window.location.href = "<?= URL('App/view/Employees/index.php') ?>";
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
