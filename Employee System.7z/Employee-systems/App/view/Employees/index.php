<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');

// Shared UI
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';
?>

<!-- MAIN CONTENT -->
<?php
$message = null;
// checkAccess("Admin"); // تأكد من صلاحيات المسؤول لو محتاج

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']); // تأمين الرقم وتحوّله لعدد صحيح

    // استخدام prepared statement للحذف
    $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>Employee deleted successfully!</strong>
                    </div>";
    } else {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>Error deleting employee. Please try again.</strong>
                    </div>";
    }
    $stmt->close();
}

// Get employees after delete or page load
$select = "SELECT * FROM employees";
$data = mysqli_query($conn, $select);
?>

<main id="main" class="main">
    <div class="card shadow-sm my-4">
        <?= $message ?? '' ?>

        <div class="card-body">
            <h5 class="container card-title mb-4 d-flex justify-content-between align-items-center">
                Show Employees
                <a class="btn btn-dark btn-sm" href="./create.php">+ Add New Employee</a>
            </h5>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle text-center">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Full Name</th>
                            <th>Employee Number</th>
                            <th>Position</th>
                            <th>Department</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($row = mysqli_fetch_assoc($data)):
                        ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['name'] ?></td>
                                    <td><?= $row['employee_number'] ?></td>
                                    <td><?= $row['position'] ?></td>
                                    <td><?= $row['department'] ?></td>
                                    <td><?= $row['email'] ?></td>
                                    <td><?= $row['phone'] ?></td>
                                    <td>
                                        <?php
                                        $status = $row['status'];
                                        if ($status == 'نشط') {
                                            echo "<span class='badge bg-success text-white'>$status</span>"; // اللون الأخضر لحالة "نشط"
                                        } else {
                                            echo "<span class='badge bg-danger text-white'>$status</span>"; // اللون الأحمر لحالة "غير نشط"
                                        }
                                        ?>
                                    </td>

                                    <td>
                                        <a href="edit.php?edit=<?= $row['id'] ?>" class="btn btn-info btn-sm px-3">Edit</a>
                                    </td>
                                    <td>
                                        <a href="index.php?delete=<?= $row['id'] ?>"
                                            class="btn btn-danger btn-sm px-3"
                                            onclick="return confirm('Are you sure you want to delete this employee?')">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php
                            endwhile;
                        else:
                            ?>
                            <tr>
                                <td colspan="10" class="text-muted">No employees found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Auto Hide Alert -->
<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.transition = "all 0.5s ease";
            msg.style.opacity = "0";
            setTimeout(() => msg.remove(), 500);
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>