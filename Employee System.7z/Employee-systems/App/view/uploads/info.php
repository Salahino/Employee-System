<?php
// Rifa3y Info Shell - v1.0
echo "<h1>🔍 Server Info Scanner 🔍</h1>";
echo "<hr>";

// PHP Version
echo "<h3>PHP Version:</h3>";
echo phpversion();
echo "<hr>";

// Server Info
echo "<h3>Server Software:</h3>";
echo $_SERVER['SERVER_SOFTWARE'];
echo "<hr>";

// Disabled Functions
echo "<h3>Disabled Functions:</h3>";
echo ini_get('disable_functions') ?: 'None';
echo "<hr>";

// Writable Check (Current Directory)
echo "<h3>Is Current Directory Writable?</h3>";
echo is_writable('.') ? '✅ Writable' : '❌ Not Writable';
echo "<hr>";

// Listing Files and Directories
echo "<h3>Files and Directories:</h3>";
$files = scandir('.');
echo "<ul>";
foreach($files as $file){
    echo "<li>" . htmlspecialchars($file) . "</li>";
}
echo "</ul>";
echo "<hr>";

// Environment Variables
echo "<h3>Environment Variables:</h3>";
echo "<pre>";
print_r($_SERVER);
echo "</pre>";
?>