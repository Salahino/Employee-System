<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');

// Shared UI
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';
?>

<?php
$message = null;

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>Task deleted successfully!</strong>
                    </div>";
    } else {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>Error deleting task. Please try again.</strong>
                    </div>";
    }
    $stmt->close();
}

// Fetch tasks with employee names
$query = "SELECT tasks.*, employees.name AS employee_name 
          FROM tasks 
          LEFT JOIN employees ON tasks.employee_id = employees.id 
          ORDER BY tasks.created_at DESC";
$data = mysqli_query($conn, $query);
?>

<main id="main" class="main">
    <div class="card shadow-sm my-4">
        <?= $message ?? '' ?>

        <div class="card-body">
            <h5 class="container card-title mb-4 d-flex justify-content-between align-items-center">
                Task List
                <a class="btn btn-dark btn-sm" href="./create.php">+ Add New Task</a>
            </h5>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle text-center">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>Task Title</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>note</th>
                            <th>Due Date</th>
                            <th>Created At</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($row = mysqli_fetch_assoc($data)):
                        ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['employee_name'] ?? 'N/A' ?></td>
                                    <td><?= $row['task_title'] ?></td>
                                    <td><?= $row['description'] ?: '—' ?></td>
                                    <td>
                                        <?php
                                        $status = $row['status'] ?? 'جارية';
                                        if ($status == 'جارية') {
                                            echo "<span class='badge bg-warning text-dark'>In Progress</span>";
                                        } else {
                                            echo "<span class='badge bg-success text-white'>Completed</span>";
                                        }
                                        ?>
                                    </td>
                                    <td><?= $row['note'] ?: '—' ?></td>
                                    <td><?= $row['due_date'] ?: '—' ?></td>
                                    <td><?= $row['created_at'] ?></td>
                                    <td>
                                        <a href="edit.php?edit=<?= $row['id'] ?>" class="btn btn-info btn-sm px-3">Edit</a>
                                    </td>
                                    <td>
                                        <a href="index.php?delete=<?= $row['id'] ?>"
                                           class="btn btn-danger btn-sm px-3"
                                           onclick="return confirm('Are you sure you want to delete this task?')">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="text-muted">No tasks found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Auto Hide Alert -->
<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.transition = "all 0.5s ease";
            msg.style.opacity = "0";
            setTimeout(() => msg.remove(), 500);
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
