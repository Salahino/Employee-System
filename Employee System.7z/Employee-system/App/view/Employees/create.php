<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';

$message = null;
$errors = [];
checkAccess("Admin") ;
// Fetch users for dropdown
$users = mysqli_query($conn, "SELECT id, username FROM users");

if (isset($_POST['send'])) {
    // Sanitize Inputs
    $name            = filterInputs($_POST['name']);
    $employee_number = filterInputs($_POST['employee_number']);
    $position        = filterInputs($_POST['position']);
    $department      = filterInputs($_POST['department']);
    $email           = filterInputs($_POST['email']);
    $phone           = filterInputs($_POST['phone']);
    $salary          = filterInputs($_POST['salary']);
    $hire_date       = filterInputs($_POST['hire_date']);
    $user_id         = filterInputs($_POST['user_id']);  // Added user_id

    // Validation
    if (empty($name)) {
        $errors['name'] = "Name is required.";
    }

    if (empty($employee_number)) {
        $errors['employee_number'] = "Employee Number is required.";
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format.";
    }

    if (!empty($salary) && !is_numeric($salary)) {
        $errors['salary'] = "Salary must be a number.";
    }

    // Check unique employee_number
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM employees WHERE employee_number = ?");
        $stmt->bind_param("s", $employee_number);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors['employee_number'] = "Employee number already exists.";
        }
        $stmt->close();
    }

    // Insert if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO employees 
            (name, employee_number, position, department, email, phone, salary, hire_date, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param("ssssssdsd", $name, $employee_number, $position, $department, $email, $phone, $salary, $hire_date, $user_id);

        if ($stmt->execute()) {
            $message = "Employee added successfully.";
        } else {
            $errors['general'] = "Error while adding employee.";
        }

        $stmt->close();
    }

    mysqli_close($conn);
}
?>

<main id="main" class="main">
    <div class="container">
        <div class="card shadow-lg my-4">
            <?php if ($message): ?>
                <div class="alert alert-success text-center mb-4" id="successMessage">
                    <h3><?= $message ?></h3>
                </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-danger text-center mb-4">
                    <?= $errors['general'] ?>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <h5 class="card-title mb-4 d-flex justify-content-between align-items-center">
                    Add Employee
                    <a class="btn btn-dark btn-sm" href="<?= URL('App/view/Employees/index.php') ?>">View All Employees</a>
                </h5>

                <form method="post" class="row g-4 needs-validation" novalidate>
                    <!-- Name -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
                        <?= isset($errors['name']) ? "<div class='invalid-feedback d-block'>{$errors['name']}</div>" : '' ?>
                    </div>

                    <!-- Employee Number -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Employee Number</label>
                        <input type="text" name="employee_number" class="form-control" placeholder="Enter employee ID" required>
                        <?= isset($errors['employee_number']) ? "<div class='invalid-feedback d-block'>{$errors['employee_number']}</div>" : '' ?>
                    </div>

                    <!-- User (Username from Users Table) -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Select User</label>
                        <select name="user_id" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php while($user = mysqli_fetch_assoc($users)): ?>
                                <option value="<?= $user['id'] ?>"><?= $user['username'] ?> - <?= $user['id'] ?></option>
                            <?php endwhile; ?>
                        </select>
                        <?= isset($errors['user_id']) ? "<div class='invalid-feedback d-block'>{$errors['user_id']}</div>" : '' ?>
                    </div>

                    <!-- Position -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Position</label>
                        <input type="text" name="position" class="form-control" placeholder="Job title">
                    </div>

                    <!-- Department -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Department</label>
                        <input type="text" name="department" class="form-control" placeholder="Department name">
                    </div>

                    <!-- Email -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="example@mail.com">
                        <?= isset($errors['email']) ? "<div class='invalid-feedback d-block'>{$errors['email']}</div>" : '' ?>
                    </div>

                    <!-- Phone -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" placeholder="Enter phone number">
                    </div>

                    <!-- Salary -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Salary</label>
                        <input type="number" name="salary" step="0.01" class="form-control" placeholder="Salary in EGP">
                        <?= isset($errors['salary']) ? "<div class='invalid-feedback d-block'>{$errors['salary']}</div>" : '' ?>
                    </div>

                    <!-- Hire Date -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Hire Date</label>
                        <input type="date" name="hire_date" class="form-control">
                    </div>

                    <!-- Buttons -->
                    <div class="col-12 text-center mt-3">
                        <button type="submit" name="send" class="btn btn-primary px-4">Submit</button>
                        <button type="reset" class="btn btn-outline-secondary px-4">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.display = 'none';
            window.location.href = "<?= URL('App/view/Employees/index.php') ?>";
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
