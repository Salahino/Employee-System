<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';

$message = null;
$errors = [];
checkAccess("Admin") ;
// Get task details by id
if (isset($_GET['edit'])) {
    $task_id = intval($_GET['edit']); // Ensure the task ID is an integer

    // Fetch task details for editing
    $query = "SELECT * FROM tasks WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $task_id);
    $stmt->execute();
    $task = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // If task doesn't exist, redirect back
    if (!$task) {
        header("Location: " . URL('App/view/Tasks/index.php'));
        exit;
    }
}

// Fetch employees for dropdown
$employees = mysqli_query($conn, "SELECT id, name FROM employees");

if (isset($_POST['send'])) {
    // Sanitize Inputs
    $employee_id = filterInputs($_POST['employee_id']);
    $task_title  = filterInputs($_POST['task_title']);
    $description = filterInputs($_POST['description']);
    $due_date    = filterInputs($_POST['due_date']);
    $status      = filterInputs($_POST['status']);  // Get the status input

    // Validation
    if (empty($employee_id)) {
        $errors['employee_id'] = "Please select an employee.";
    }

    if (empty($task_title)) {
        $errors['task_title'] = "Please enter the task title.";
    }

    // Update if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE tasks SET employee_id = ?, task_title = ?, description = ?, due_date = ?, status = ? WHERE id = ?");
        $stmt->bind_param("issssi", $employee_id, $task_title, $description, $due_date, $status, $task_id);

        if ($stmt->execute()) {
            $message = "Task updated successfully.";
        } else {
            $errors['general'] = "An error occurred while updating the task.";
        }

        $stmt->close();
    }

    mysqli_close($conn);
}
?>

<main id="main" class="main">
    <div class="container">
        <div class="card shadow-lg my-4">
            <?php if ($message): ?>
                <div class="alert alert-success text-center mb-4" id="successMessage">
                    <h3><?= $message ?></h3>
                </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-danger text-center mb-4">
                    <?= $errors['general'] ?>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <h5 class="card-title mb-4 d-flex justify-content-between align-items-center">
                    Edit Task
                    <a class="btn btn-dark btn-sm" href="<?= URL('App/view/Tasks/index.php') ?>">View All Tasks</a>
                </h5>

                <form method="post" class="row g-4 needs-validation" novalidate>
                    <!-- Employee -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Select Employee</label>
                        <select name="employee_id" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php while ($emp = mysqli_fetch_assoc($employees)): ?>
                                <option value="<?= $emp['id'] ?>" <?= $emp['id'] == $task['employee_id'] ? 'selected' : '' ?>>
                                    <?= $emp['name'] ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <?= isset($errors['employee_id']) ? "<div class='invalid-feedback d-block'>{$errors['employee_id']}</div>" : '' ?>
                    </div>

                    <!-- Task Title -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Task Title</label>
                        <input type="text" name="task_title" class="form-control" value="<?= $task['task_title'] ?>" placeholder="e.g., Review Reports" required>
                        <?= isset($errors['task_title']) ? "<div class='invalid-feedback d-block'>{$errors['task_title']}</div>" : '' ?>
                    </div>

                    <!-- Description -->
                    <div class="col-12">
                        <label class="form-label">Description (optional)</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Write task details..."><?= $task['description'] ?></textarea>
                    </div>

                    <!-- Due Date -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Due Date</label>
                        <input type="date" name="due_date" class="form-control" value="<?= $task['due_date'] ?>">
                    </div>

                    <!-- Status -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control" required>
                            <option value="جارية" <?= $task['status'] == 'جارية' ? 'selected' : '' ?>>In Progress</option>
                            <option value="منتهية" <?= $task['status'] == 'منتهية' ? 'selected' : '' ?>>Completed</option>
                        </select>
                    </div>

                    <!-- Buttons -->
                    <div class="col-12 text-center mt-3">
                        <button type="submit" name="send" class="btn btn-primary px-4">Submit</button>
                        <button type="reset" class="btn btn-outline-secondary px-4">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.display = 'none';
            window.location.href = "<?= URL('App/view/Tasks/index.php') ?>";
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>