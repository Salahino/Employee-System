<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';

$message = null;
$errors = [];
checkAccess("Admin") ;
// Fetch employees for dropdown
$employees = mysqli_query($conn, "SELECT id, name FROM employees");

if (isset($_POST['send'])) {
    // Sanitize Inputs
    $employee_id = filterInputs($_POST['employee_id']);
    $task_title  = filterInputs($_POST['task_title']);
    $description = filterInputs($_POST['description']);
    $due_date    = filterInputs($_POST['due_date']);

    // Validation
    if (empty($employee_id)) {
        $errors['employee_id'] = "Please select an employee.";
    }

    if (empty($task_title)) {
        $errors['task_title'] = "Please enter the task title.";
    }

    // Insert if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO tasks (employee_id, task_title, description, due_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $employee_id, $task_title, $description, $due_date);

        if ($stmt->execute()) {
            $message = "Task added successfully.";
        } else {
            $errors['general'] = "An error occurred while adding the task.";
        }

        $stmt->close();
    }

    mysqli_close($conn);
}
?>

<main id="main" class="main">
    <div class="container">
        <div class="card shadow-lg my-4">
            <?php if ($message): ?>
                <div class="alert alert-success text-center mb-4" id="successMessage">
                    <h3><?= $message ?></h3>
                </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-danger text-center mb-4">
                    <?= $errors['general'] ?>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <h5 class="card-title mb-4 d-flex justify-content-between align-items-center">
                    Add New Task
                    <a class="btn btn-dark btn-sm" href="<?= URL('App/view/Tasks/index.php') ?>">View All Tasks</a>
                </h5>

                <form method="post" class="row g-4 needs-validation" novalidate>
                    <!-- Employee -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Select Employee</label>
                        <select name="employee_id" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php while($emp = mysqli_fetch_assoc($employees)): ?>
                                <option value="<?= $emp['id'] ?>"><?= $emp['name'] ?></option>
                            <?php endwhile; ?>
                        </select>
                        <?= isset($errors['employee_id']) ? "<div class='invalid-feedback d-block'>{$errors['employee_id']}</div>" : '' ?>
                    </div>

                    <!-- Task Title -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Task Title</label>
                        <input type="text" name="task_title" class="form-control" placeholder="e.g., Review Reports" required>
                        <?= isset($errors['task_title']) ? "<div class='invalid-feedback d-block'>{$errors['task_title']}</div>" : '' ?>
                    </div>

                    <!-- Description -->
                    <div class="col-12">
                        <label class="form-label">Description (optional)</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Write task details..."></textarea>
                    </div>

                    <!-- Due Date -->
                    <div class="col-md-6 col-12">
                        <label class="form-label">Due Date</label>
                        <input type="date" name="due_date" class="form-control">
                    </div>

                    <!-- Buttons -->
                    <div class="col-12 text-center mt-3">
                        <button type="submit" name="send" class="btn btn-primary px-4">Submit</button>
                        <button type="reset" class="btn btn-outline-secondary px-4">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.display = 'none';
            window.location.href = "<?= URL('App/view/Tasks/index.php') ?>";
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
