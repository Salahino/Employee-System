<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');





// Shared UI
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php'; ?>
 
<?php
$message = null;
$errors = [];
checkAccess("Admin");

if (isset($_POST['send'])) {
    // Sanitize & Validate Inputs
    $fullname = filterInputs($_POST['fullname']);
    $username = filterInputs($_POST['username']);
    $password = filterInputs($_POST['password']);
    $role = filterInputs($_POST['role']);

    if (empty($fullname)) {
        $errors['fullname'] = "Full name is required.";
    }

    if (empty($username)) {
        $errors['username'] = "Username is required.";
    }

    if (empty($password)) {
        $errors['password'] = "Password is required.";
    }

    if (empty($role)) {
        $errors['role'] = "Role is required.";
    } elseif (!in_array($role, ['admin', 'employee'])) {
        $errors['role'] = "Invalid role selected.";
    }
    

    // Check for existing username
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors['username'] = "Username is already taken.";
        }
        $stmt->close();
    }

    // Insert user if no errors
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (fullname, username, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fullname, $username, $hashedPassword, $role);

        if ($stmt->execute()) {
            $message = "User created successfully.";
        } else {
            $errors['general'] = "Error while creating user.";
        }

        $stmt->close();
    }
}

mysqli_close($conn);
?>

<!-- HTML Form -->
<main id="main" class="main">
    <div class="card shadow-sm my-4">
        <?php if ($message): ?>
            <div class="alert alert-success text-center mb-4" id="successMessage">
                <h3><?= $message ?></h3>
            </div>
        <?php endif; ?>

        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-danger text-center mb-4">
                <?= $errors['general'] ?>
            </div>
        <?php endif; ?>

        <div class="card-body">
            <h5 class="container card-title mb-4">
                Add  User
                <a class="float-end btn btn-dark btn-sm" href="<?= URL('App/view/Users/index.php') ?>">View All Users</a>
            </h5>

            <form method="post" class="row g-3 needs-validation" id="userForm" novalidate>
                <!-- Full Name -->
                <div class="col-md-12">
                    <label for="fullname" class="form-label">Full Name</label>
                    <input type="text" id="fullname" name="fullname" class="form-control" required>
                    <?php if (isset($errors['fullname'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['fullname'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Username -->
                <div class="col-md-12">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                    <?php if (isset($errors['username'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['username'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="col-md-12">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                    <?php if (isset($errors['password'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['password'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Role -->
                <div class="col-md-12">
                    <label for="role" class="form-label">Role</label>
                    <select id="role" name="role" class="form-select" required>
                        <option value="">Choose...</option>
                        <option value="admin" <?= (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                        <option value="employee" <?= (isset($_POST['role']) && $_POST['role'] == 'employee') ? 'selected' : '' ?>>User</option>
                    </select>
                    <?php if (isset($errors['role'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['role'] ?></div>
                    <?php endif; ?>
                </div>


                <!-- Buttons -->
                <div class="text-center mt-4">
                    <button type="submit" name="send" class="btn btn-primary px-4">Submit</button>
                    <button type="reset" class="btn btn-secondary px-4">Reset</button>
                </div>
            </form>
        </div>
    </div>
</main>
</section>

<script>
    setTimeout(() => {
        document.getElementById('successMessage')?.style.display = 'none';
        document.getElementById('userForm')?.reset();
    }, 3000);
</script>
<script>
    setTimeout(() => {
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';

            // إعادة توجيه بعد إخفاء الرسالة
            window.location.href = "<?= URL('App/view/Users/index.php') ?>"; // عدّل الرابط لو مكان الصفحة مختلف
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>