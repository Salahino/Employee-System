<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');

include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';
?>

<!-- MAIN CONTENT -->
<?php
$message = null;
 checkAccess("Admin");

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']); // تأمين الرقم

    // استخدام prepared statement
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>User deleted successfully!</strong>
                    </div>";
    } else {
        $message = "<div class='alert alert-danger text-center' id='successMessage'>
                        <strong>Error deleting user. Please try again.</strong>
                    </div>";
    }

    $stmt->close();
}

// Get users after delete or page load
$select = "SELECT * FROM users";
$data = mysqli_query($conn, $select);
?>

<main id="main" class="main">
    <div class="card shadow-sm my-4">
        <?= $message ?? '' ?>

        <div class="card-body">
            <h5 class="container card-title mb-4">
                Show Users
                <a class="float-end btn btn-dark btn-sm" href="./create.php">+ Add New User</a>
            </h5>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle text-center">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($row = mysqli_fetch_assoc($data)):
                        ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['fullname'] ?></td>
                                    <td><?= $row['username'] ?></td>
                                    <td><?= ucfirst($row['role']) ?></td>
                                    <td>
                                        <a href="edit.php?edit=<?= $row['id'] ?>" class="btn btn-info btn-sm px-3">Edit</a>
                                    </td>
                                    <td>
                                        <a href="index.php?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm px-3" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                    </td>
                                </tr>
                        <?php
                            endwhile;
                        else:
                        ?>
                            <tr>
                                <td colspan="6" class="text-muted">No users found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Auto Hide Alert -->
<script>
    setTimeout(() => {
        const msg = document.getElementById('successMessage');
        if (msg) {
            msg.style.transition = "all 0.5s ease";
            msg.style.opacity = "0";
            setTimeout(() => msg.remove(), 500);
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
