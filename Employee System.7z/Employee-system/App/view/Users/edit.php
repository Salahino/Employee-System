<?php
// Database Connection
include_once(__DIR__ . '/../../configDatabase.php');
include_once(__DIR__ . '/../../functions.php');

// Shared UI
include_once '../../.././shared/head.php';
include_once '../../.././shared/sidebar.php';
checkAccess("Admin") ;
$message = null;
$errors = [];
$user = [
    'fullname' => '',
    'username' => '',
    'role' => ''
];

// Check if we're editing
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
    } else {
        $errors['general'] = "User not found.";
    }
    $stmt->close();
}

// Handle form submission
if (isset($_POST['send'])) {
    $fullname = filterInputs($_POST['fullname']);
    $username = filterInputs($_POST['username']);
    $password = filterInputs($_POST['password']);
    $role = filterInputs($_POST['role']);

    if (empty($fullname)) $errors['fullname'] = "Full name is required.";
    if (empty($username)) $errors['username'] = "Username is required.";
    if (empty($role)) $errors['role'] = "Role is required.";
    elseif (!in_array($role, ['admin', 'employee'])) $errors['role'] = "Invalid role.";

    // Update user if no errors
    if (empty($errors)) {
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET fullname=?, username=?, password=?, role=? WHERE id=?");
            $stmt->bind_param("ssssi", $fullname, $username, $hashedPassword, $role, $id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET fullname=?, username=?, role=? WHERE id=?");
            $stmt->bind_param("sssi", $fullname, $username, $role, $id);
        }

        if ($stmt->execute()) {
            $message = "User updated successfully.";
        } else {
            $errors['general'] = "Error while updating user.";
        }
        $stmt->close();
    }

    // Keep user data to refill form
    $user = ['fullname' => $fullname, 'username' => $username, 'role' => $role];
}
?>

<!-- HTML Form -->
<main id="main" class="main">
    <div class="card shadow-sm my-4">
        <?php if ($message): ?>
            <div class="alert alert-success text-center mb-4" id="successMessage">
                <h3><?= $message ?></h3>
            </div>
        <?php endif; ?>

        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-danger text-center mb-4">
                <?= $errors['general'] ?>
            </div>
        <?php endif; ?>

        <div class="card-body">
            <h5 class="container card-title mb-4">
                Edit User
                <a class="float-end btn btn-dark btn-sm" href="<?= URL('App/view/Users/index.php') ?>">Back to Users</a>
            </h5>

            <form method="post" class="row g-3 needs-validation" id="userForm" novalidate>
                <!-- Full Name -->
                <div class="col-md-12">
                    <label for="fullname" class="form-label">Full Name</label>
                    <input type="text" id="fullname" name="fullname" class="form-control" required value="<?= htmlspecialchars($user['fullname']) ?>">
                    <?php if (isset($errors['fullname'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['fullname'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Username -->
                <div class="col-md-12">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required value="<?= htmlspecialchars($user['username']) ?>">
                    <?php if (isset($errors['username'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['username'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Password -->
                <div class="col-md-12">
                    <label for="password" class="form-label">New Password (Leave blank to keep current)</label>
                    <input type="password" id="password" name="password" class="form-control">
                    <?php if (isset($errors['password'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['password'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Role -->
                <div class="col-md-12">
                    <label for="role" class="form-label">Role</label>
                    <select id="role" name="role" class="form-select" required>
                        <option value="">Choose...</option>
                        <option value="admin" <?= ($user['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                        <option value="employee" <?= ($user['role'] == 'employee') ? 'selected' : '' ?>>User</option>
                    </select>
                    <?php if (isset($errors['role'])): ?>
                        <div class="invalid-feedback d-block"><?= $errors['role'] ?></div>
                    <?php endif; ?>
                </div>

                <!-- Buttons -->
                <div class="text-center mt-4">
                    <button type="submit" name="send" class="btn btn-primary px-4">Update</button>
                    <a href="<?= URL('App/view/Users/index.php') ?>" class="btn btn-secondary px-4">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</main>
</section>

<!-- Auto Hide Alert -->
<script>
    setTimeout(() => {
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
            // Redirect after update (optional)
            window.location.href = "<?= URL('App/view/Users/index.php') ?>";
        }
    }, 3000);
</script>

<?php include_once '../../.././shared/script.php'; ?>
