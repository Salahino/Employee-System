<?php
// Database Connection
// Database Connection
include_once(__DIR__ . '/../configDatabase.php');
include_once(__DIR__ . '/../functions.php');

// Shared UI
include_once '../.././shared/head.php';

// CSRF Token Validation
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Create a new CSRF token if none exists
}
function checkCSRFToken()
{
    if (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        return true;
    } else {
        return false;
    }
}

checkAccess('employee');

// Get user_id from session
$user_id = $_SESSION['user']['id'];

// Success message after completing a task
$message = null;

// Handle task completion
if (isset($_POST['complete_task'])) {
    if (!checkCSRFToken()) {
        $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>Invalid CSRF token. Please try again.</strong></div>";
    } else {
        $id = intval($_POST['task_id']);
        $note = filterInputs(trim($_POST['note']));
        $uploadOk = 1;
        $fileName = null;

        // File upload processing
        if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
            $allowedTypes = ['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'zip'];
            $fileExt = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

            if (in_array($fileExt, $allowedTypes)) {
                $uploadsDir = __DIR__ . '/uploads/';
                if (!is_dir($uploadsDir)) {
                    mkdir($uploadsDir, 0777, true);
                }
                $fileName = uniqid() . '.' . $fileExt;
                $targetFile = $uploadsDir . $fileName;

                // Check if file is a real file (to avoid malicious file uploads)
                if (getimagesize($_FILES['file']['tmp_name']) === false && $fileExt != 'pdf' && $fileExt != 'zip') {
                    $uploadOk = 0;
                    $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>Invalid file type.</strong></div>";
                } else {
                    if (!move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
                        $uploadOk = 0;
                        $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>Failed to upload file.</strong></div>";
                    }
                }
            } else {
                $uploadOk = 0;
                $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>Invalid file type.</strong></div>";
            }
        }

        if ($uploadOk) {
            $checkStmt = $conn->prepare("SELECT tasks.id FROM tasks
                                         JOIN employees ON tasks.employee_id = employees.id
                                         WHERE tasks.id = ? AND employees.user_id = ?");
            $checkStmt->bind_param("ii", $id, $user_id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();

            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("UPDATE tasks SET status = 'منتهية', note = ?, file_path = ? WHERE id = ?");
                $stmt->bind_param("ssi", $note, $fileName, $id);
                if ($stmt->execute()) {
                    $message = "<div class='alert alert-success text-center' id='successMessage'><strong>Task completed successfully!</strong></div>";
                } else {
                    $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>Error updating the task. Try again.</strong></div>";
                }
                $stmt->close();
            } else {
                $message = "<div class='alert alert-danger text-center' id='errorMessage'><strong>You do not have permission to update this task.</strong></div>";
            }
        }
    }
}

// Fetch active and completed tasks separately
$query_active = "SELECT tasks.*, employees.name AS employee_name
                 FROM tasks
                 JOIN employees ON tasks.employee_id = employees.id
                 WHERE employees.user_id = ? AND tasks.status != 'منتهية'
                 ORDER BY tasks.created_at DESC";
$stmt_active = $conn->prepare($query_active);
$stmt_active->bind_param("i", $user_id);
$stmt_active->execute();
$active_tasks = $stmt_active->get_result();

$query_completed = "SELECT tasks.*, employees.name AS employee_name
                    FROM tasks
                    JOIN employees ON tasks.employee_id = employees.id
                    WHERE employees.user_id = ? AND tasks.status = 'منتهية'
                    ORDER BY tasks.created_at DESC";
$stmt_completed = $conn->prepare($query_completed);
$stmt_completed->bind_param("i", $user_id);
$stmt_completed->execute();
$completed_tasks = $stmt_completed->get_result();
?>

<main id="main" class="main position-relative">
    <!-- CSRF Token -->
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

    <!-- Logout Button -->
    <div style="position: absolute; top: 20px; right: 30px; z-index: 1000;">
        <button id="logout-btn" class="btn btn-outline-danger d-flex align-items-center gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-box-arrow-right" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10 15a1 1 0 0 0 1-1v-2h-1v2H2V2h8v2h1V2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8z" />
                <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708L12.172 4.5l-.708.708L14.293 8l-2.829 2.793.708.707 3.682-3.646z" />
                <path fill-rule="evenodd" d="M5.5 8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 0-1h-9a.5.5 0 0 0-.5.5z" />
            </svg>
            Logout
        </button>
    </div>

    <style>
        .custom-file-upload button {
            /* background-color: #4CAF50; */
            color: white;
            font-weight: bold;
            padding: 10px;
            border-radius: 12px;
            border: none;
            transition: background-color 0.3s ease;
        }

        .file-preview {
            position: relative;
            width: 100%;
            text-align: center;
        }

        .file-info {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .file-info span {
            font-weight: bold;
            color: #333;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .file-info .remove-file {
            position: absolute;
            top: 5px;
            right: 5px;
            background-color: rgba(255, 0, 0, 0.8);
            border: none;
            color: white;
            font-size: 16px;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .file-info .remove-file:hover {
            background-color: rgba(200, 0, 0, 1);
        }
    </style>
    <div class="container py-5">
        <?= $message ?? '' ?>

        <h3 class="text-center mb-4">Your Assigned Tasks</h3>

        <div class="row justify-content-center g-4">
            <?php if ($active_tasks && mysqli_num_rows($active_tasks) > 0): ?>
                <?php while ($task = mysqli_fetch_assoc($active_tasks)): ?>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-lg rounded-4">
                            <div class="card-body p-4">
                                <h5 class="card-title fw-bold text-primary mb-2"><?= $task['task_title'] ?></h5>
                                <p class="card-text text-muted"><?= $task['description'] ?: 'No description provided.' ?></p>
                                <p class="mb-1"><strong>Assigned to:</strong> <?= $task['employee_name'] ?></p>
                                <p class="mb-1"><strong>Status:</strong> <span class='badge bg-warning text-dark'>In Progress</span></p>
                                <p class="mb-3"><strong>Due:</strong> <?= $task['due_date'] ?: 'N/A' ?></p>

                                <form method="post" enctype="multipart/form-data">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                    <input type="hidden" name="task_id" value="<?= $task['id'] ?>">

                                    <div class="mb-3">
                                        <label for="file_<?= $task['id'] ?>" class="form-label fw-bold">Upload File:</label>
                                        <div class="custom-file-upload" id="filePreviewContainer_<?= $task['id'] ?>">
                                            <input type="file" name="file" id="file_<?= $task['id'] ?>" onchange="previewFile(event, <?= $task['id'] ?>)" required hidden>
                                            <button type="button" class="btn btn-primary w-100" onclick="document.getElementById('file_<?= $task['id'] ?>').click();">
                                                <i class="bi bi-upload"></i> Upload File
                                            </button>

                                            <div id="preview_<?= $task['id'] ?>" class="file-preview mt-3" style="display: none;">
                                                <div class="file-info bg-light p-2 rounded-3 d-flex align-items-center justify-content-between shadow-sm position-relative">
                                                    <span id="file_name_<?= $task['id'] ?>" class="text-truncate" style="max-width: 80%;">File name here</span>
                                                    <button type="button" class="remove-file" onclick="removeFile(<?= $task['id'] ?>)">×</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="note" class="form-label fw-bold">Note:</label>
                                        <textarea name="note" id="note" class="form-control" rows="4" placeholder="Add a note for this task (optional)"></textarea>
                                    </div>

                                    <button type="submit" name="complete_task" class="btn btn-success w-100">
                                        <i class="bi bi-check-circle"></i> Complete Task
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-md-12 text-center">
                    <p class="text-muted">No active tasks found.</p>
                </div>
            <?php endif; ?>
            <hr class="my-5">

            <h4 class="text-center mb-4">Completed Tasks</h4>

            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Assigned To</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($completed_tasks && mysqli_num_rows($completed_tasks) > 0): ?>
                            <?php $i = 1;
                            while ($row = mysqli_fetch_assoc($completed_tasks)): ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['task_title'] ?></td>
                                    <td><?= $row['description'] ?: 'N/A' ?></td>
                                    <td><?= $row['employee_name'] ?></td>
                                    <td><?= $row['due_date'] ?: 'N/A' ?></td>
                                    <td><span class='badge bg-success text-white'>Completed</span></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No completed tasks found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
</main>

<!-- Script for handling file previews -->
<script>
    function previewFile(event, taskId) {
        const file = event.target.files[0];
        const preview = document.getElementById('preview_' + taskId);
        const fileName = document.getElementById('file_name_' + taskId);

        if (file) {
            fileName.textContent = file.name;
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
    }

    function removeFile(taskId) {
        const fileInput = document.getElementById('file_' + taskId);
        const preview = document.getElementById('preview_' + taskId);
        fileInput.value = '';
        preview.style.display = 'none';
    }
</script>

<!-- Include your footer and scripts -->
<?php include_once '../.././shared/script.php'; ?>