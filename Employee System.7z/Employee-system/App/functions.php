<?php

session_start();
define("BASE_URL", 'http://localhost/Employee-system/');

function URL($var = null)
{
    return BASE_URL . $var;
}
define('MAIN_URL','http://localhost/Employee-system/');
function base_url($url=null){
    return MAIN_URL.$url; }


function testMessage($condication, $message)
{
    if ($condication) {
        return  $message;
    }
}



function redirect($var = null)
{
    echo "<script>
window.location.replace('http://localhost/Employee-system/$var');
</script>";
}

function checkAccess($roleRequired) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // تأكد من وجود بيانات المستخدم
    if (!isset($_SESSION['user']) || !isset($_SESSION['user']['role'])) {
        redirect('login.php');
        exit();
    }

    // خلي الدور كله small letters للمقارنة الدقيقة
    $userRole = strtolower($_SESSION['user']['role']);
    $requiredRole = strtolower($roleRequired);

    // لو الدور مش مطابق
    if ($userRole != $requiredRole) {
        // احصل على اسم الصفحة الحالية
        $currentPage = basename($_SERVER['PHP_SELF']);

        if ($userRole === 'employee' && $currentPage !== 'Submiss.php') {
            redirect('App/view/Submiss.php');
        } elseif ($userRole === 'admin' && $currentPage !== '') {
            redirect('');
        } else {
            redirect('login.php');
        }
        exit();
    }
}




function auth($rule2 = null, $rule3 = null, $rule4 = null)
{
    include_once './configDatabase.php';
    if ($_SESSION['user']) {
        $user_id = $_SESSION['user']['id'];
        $select = "SELECT * FROM tusears WHERE id = $user_id";
        $data = mysqli_query($conn, $select);
        $user = mysqli_fetch_assoc($data);
        if (
            
            $user['Validit'] == 1 || $user['Validit'] == $rule2
            || $user['Validit'] == $rule4
            || $user['Validit'] == $rule3
        ) {
        } else {
            redirect('pages-error-404.php');
        }
    } else {
        redirect('pages-login.php');
    }
}


// filter All Inputs
function filterInputs($input)
{
    $input  = trim($input);
    $input  = strip_tags($input);
    $input  = stripslashes($input);
    $input  = htmlspecialchars($input);
    return $input;
}


// String Validation;

function stringValidation($input, $min = 3, $max = 20)
{
    $emptyError = empty($input);
    $minError = strlen($input) < $min;
    $maxError = strlen($input) >  $max;
    if ($emptyError == true || $minError == true || $maxError == true) {
        return true;
    } else {
        return false;
    }
}

// Number Validation

function numberValidation($input, $numberStatus = 'int')
{
    $emptyError = empty($input);
    $isNagtiveError = $input <= 0;
    if ($numberStatus == 'int') {
        $isNumberError = filter_var($input, FILTER_VALIDATE_INT) == false;
    } else {
        $isNumberError = filter_var($input, FILTER_VALIDATE_FLOAT) == false;
    }

    if ($emptyError == true || $isNagtiveError == true || $isNumberError == true) {
        return true;
    } else {
        return false;
    }
}

function fileReq($file_name)
{
    $emptyError = empty($file_name);
    if ($emptyError == true) {
        return true;
    } else {
        return false;
    }
}

function sizeFile($fileSize, $your_size = 2)
{
    $sizeByMiga = ($fileSize / 1024) / 1024;
    if ($sizeByMiga > $your_size) {
        return true;
    } else {
        return false;
    }
}

function validationType(
    $file_type,
    $type1 = null,
    $type2 = null,
    $type3 = null,
    $type4 = null,
    $type5 = null,
) {
    if (
        $file_type == $type1 || $file_type == $type2 ||
        $file_type == $type3 || $file_type == $type4 ||
        $file_type == $type5
    ) {
        return false;
    } else {
        return true;
    }
}
