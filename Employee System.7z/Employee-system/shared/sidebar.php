
<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <!-- <img src="logo.png" width="50px" style="margin-right:  7px;" height="50px" alt=""> -->
        <span>Employee Management</span>
    </a>

    <ul class="side-menu">
        <li><a href="index.html" class="active"><i class='bx bxs-dashboard icon'></i> Home</a></li>

        <li>
            <a href="#"><i class='bx bxs-user icon'></i> Employees <i class='bx bx-chevron-right icon-right'></i></a>
            <ul class="side-dropdown">
                <li><a href="http://localhost/Employee-system/App/view/Employees/create.php">Add Employee</a></li>
                <li><a href="http://localhost/Employee-system/App/view/Employees/index.php">View Employees</a></li>
            </ul>
        </li>

        <li>
            <a href="#"><i class='bx bxs-briefcase icon'></i> Tasks <i class='bx bx-chevron-right icon-right'></i></a>
            <ul class="side-dropdown">
                <li><a href="http://localhost/Employee-system/App/view/Tasks/create.php">Add Task</a></li>
                <li><a href="http://localhost/Employee-system/App/view/Tasks/index.php">View Tasks</a></li>
            </ul>
        </li>

       

        <!-- Users -->
        <li>
            <a href="#"><i class='bx bxs-group icon'></i> Users <i class='bx bx-chevron-right icon-right'></i></a>
            <ul class="side-dropdown">
                <li><a href="http://localhost/Employee-system/App/view/Users/create.php">Add User </a></li>
                <li><a href="http://localhost/Employee-system/App/view/Users/index.php">View Users</a></li>
            </ul>
        </li>

        <li>
            <a href="#" id="logout-btn">
                <i class='bx bx-log-out icon'></i> Logout
            </a>
        </li>
    </ul>
</section>
<!-- End SIDEBAR -->
<!-- NAVBAR -->

<section id="content">
    <nav>
        <i class='bx bx-menu toggle-sidebar'></i>
    </nav>

