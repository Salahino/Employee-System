<div class="overlay" id="overlay"></div>

<div class="logout-alert" id="logout-alert">
    <h3>Are you sure you want to logout?</h3>
    <button class="logout-yes" id="confirm-logout">Yes</button>
    <button class="logout-no" id="cancel-logout">No</button>
</div>

<script>
    // جلب العناصر
    const logoutBtn = document.getElementById('logout-btn');
    const logoutAlert = document.getElementById('logout-alert');
    const overlay = document.getElementById('overlay');
    const confirmLogout = document.getElementById('confirm-logout');
    const cancelLogout = document.getElementById('cancel-logout');

    // عند الضغط على زر الخروج
    logoutBtn.addEventListener('click', () => {
        logoutAlert.classList.add('show');  // إظهار نافذة التأكيد
        overlay.classList.add('show');      // إظهار الطبقة المظلمة
    });

    // عند الضغط على "لا" لغلق نافذة التأكيد
    cancelLogout.addEventListener('click', () => {
        logoutAlert.classList.remove('show');
        overlay.classList.remove('show');
    });

    // عند الضغط على "نعم" لتسجيل الخروج
    confirmLogout.addEventListener('click', () => {
        // إعادة التوجيه إلى صفحة logout.php
        window.location.href = 'http://localhost/Employee-system/logout.php'; // التوجيه إلى صفحة logout.php
    });

    // عند الضغط على الطبقة المظلمة (overlay) لإغلاق نافذة التأكيد
    overlay.addEventListener('click', () => {
        logoutAlert.classList.remove('show');
        overlay.classList.remove('show');
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="<?= base_url('assets/js/dashboard.js')?>"></script>
</body>

</html>