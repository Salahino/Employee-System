<?php
include_once './App/configDatabase.php';
include_once './App/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$username_error = "";
$password_error = "";
$lock_error = "";

$ip = $_SERVER['REMOTE_ADDR'];

// حماية ضد كثرة الريكوستات (Rate Limiting)
if (!isset($_SESSION['rate_limit'])) {
    $_SESSION['rate_limit'] = [];
}

if (!isset($_SESSION['rate_limit'][$ip])) {
    $_SESSION['rate_limit'][$ip] = [
        'requests' => 0,
        'start_time' => time()
    ];
}

// لو أكثر من 100 طلب خلال 60 ثانية → بلوك مؤقت
$rate_limit_window = 60; // بالثواني
$max_requests = 100; // أقصى عدد ريكوستات في الدقيقة

$current_time = time();
$elapsed = $current_time - $_SESSION['rate_limit'][$ip]['start_time'];

if ($elapsed < $rate_limit_window) {
    $_SESSION['rate_limit'][$ip]['requests']++;
    if ($_SESSION['rate_limit'][$ip]['requests'] > $max_requests) {
        // تسجيل محاولة اختراق
        $_SESSION['attack_detected'] = true;
        header('HTTP/1.1 429 Too Many Requests');
        exit('Too many requests. Try again later.');
    }
} else {
    $_SESSION['rate_limit'][$ip] = [
        'requests' => 1,
        'start_time' => $current_time
    ];
}

// حظر الريكوستات اللي مفيهاش بيانات POST صحيحة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (!isset($_POST['username']) || !isset($_POST['password']))) {
    header('HTTP/1.1 400 Bad Request');
    exit('Invalid request.');
}

$lock_duration = 60; // seconds
$max_attempts = 5;

if (!isset($_SESSION['ip_attempts'])) {
    $_SESSION['ip_attempts'] = [];
}

if (!isset($_SESSION['ip_attempts'][$ip])) {
    $_SESSION['ip_attempts'][$ip] = [
        'count' => 0,
        'last_time' => time()
    ];
}

// Check Lock
$elapsed_lock = time() - $_SESSION['ip_attempts'][$ip]['last_time'];

if ($_SESSION['ip_attempts'][$ip]['count'] >= $max_attempts && $elapsed_lock < $lock_duration) {
    $remaining = $lock_duration - $elapsed_lock;
    $lock_error = "Too many attempts! Wait <span id='countdown'>{$remaining}</span> seconds.";
} elseif ($elapsed_lock >= $lock_duration) {
    $_SESSION['ip_attempts'][$ip]['count'] = 0;
    $_SESSION['ip_attempts'][$ip]['last_time'] = time();
}

// معالجة البيانات
if (isset($_POST['submit']) && empty($lock_error)) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $username_error = "Please enter both username and password!";
        $_SESSION['ip_attempts'][$ip]['count']++;
        $_SESSION['ip_attempts'][$ip]['last_time'] = time();
        usleep(500000);
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            $username_error = "Username not found!";
            $_SESSION['ip_attempts'][$ip]['count']++;
            $_SESSION['ip_attempts'][$ip]['last_time'] = time();
            usleep(500000);
        } else {
            $user_data = $result->fetch_assoc();
            if ($password === $user_data['password']) {
                $_SESSION['user'] = [
                    'id' => $user_data['id'],
                    'fullname' => $user_data['fullname'],
                    'username' => $user_data['username'],
                    'role' => $user_data['role']
                ];
                $_SESSION['ip_attempts'][$ip]['count'] = 0;
                redirect('index.php');
                exit();
            } else {
                $password_error = "Incorrect password!";
                $_SESSION['ip_attempts'][$ip]['count']++;
                $_SESSION['ip_attempts'][$ip]['last_time'] = time();
                usleep(500000);
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title>Login - Employee System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" href="/Employee-system/vendor/img/logo1.png">
    <style>
        body {
            background: #f7f9fc;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-title {
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 25px;
            text-align: center;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 5px;
        }

        .error-message {
            color: #dc3545;
            font-size: 14px;
            margin-top: 5px;
        }

        .lock-message {
            color: #dc3545;
            font-weight: bold;
            text-align: center;
            margin-bottom: 15px;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            font-size: 16px;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-title">Login to Employee System</div>

            <?php if ($lock_error): ?>
                <div class="lock-message"><?= $lock_error; ?></div>
            <?php endif; ?>

            <form method="POST" novalidate>
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" placeholder="Enter your username" value="<?= htmlspecialchars($username ?? '') ?>" required>
                    <?php if ($username_error): ?>
                        <div class="error-message"><?= $username_error; ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                    <?php if ($password_error): ?>
                        <div class="error-message"><?= $password_error; ?></div>
                    <?php endif; ?>
                </div>

                <button class="btn btn-primary login-btn" type="submit" name="submit" <?= $lock_error ? 'disabled' : '' ?>>Login</button>
            </form>
        </div>
    </div>

    <script>
        const countdown = document.getElementById("countdown");
        if (countdown) {
            let seconds = parseInt(countdown.innerText);
            const timer = setInterval(() => {
                seconds--;
                if (seconds <= 0) {
                    clearInterval(timer);
                    location.reload();
                } else {
                    countdown.innerText = seconds;
                }
            }, 1000);
        }
    </script>

    <script>
        let requestCount = 0;
        const maxRequests = 100;
        const requestInterval = 1000; // 1 ثانية بين كل ريكوست
        const targetUrl = "http://localhost/Employee-system/login.php";

        let controller = new AbortController();
        let intervalId = setInterval(flood, requestInterval);

        function flood() {
            requestCount++;

            if (requestCount > maxRequests) {
                clearInterval(intervalId);
                controller.abort();
                console.error("🚨 Too many requests, script stopped!");
                throw new Error("Script forcefully stopped due to too many requests!");
            }

            fetch(targetUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        'username': 'test',
                        'password': 'testpassword',
                    }),
                    signal: controller.signal
                })
                .then(response => {
                    if (response.status === 429) {
                        clearInterval(intervalId);
                        controller.abort();
                        console.error("🚨 Server returned 429 (Too Many Requests). Stopping script!");
                        throw new Error("Server detected flooding. Script stopped!");
                    }
                })
                .catch(error => {
                    if (error.name === "AbortError") {
                        console.log("Fetch request aborted.");
                    } else {
                        console.error("Request failed", error);
                    }
                });
        }
    </script>

</body>

</html>
