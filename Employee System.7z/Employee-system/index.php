<?php
include_once './shared/head.php';
include_once './shared/sidebar.php';
checkAccess("Admin") ;
?>
<!-- MAIN CONTENT -->
<main id="main">
    <!-- Add your page content here -->
    <div class="text-center ">

        <h1>Welcome to Employee-system Dashboard</h1>
        
    </div>
</main>
</section>
<?php include_once './shared/script.php';?>